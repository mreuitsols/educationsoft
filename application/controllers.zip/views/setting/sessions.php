<div class="col-md-6">  
<select class="form-control"">
  <option>Select Session</option>
  <option>2018</option>
  <option>2019</option>
  <option>2020</option>
</select>
    
  </div>