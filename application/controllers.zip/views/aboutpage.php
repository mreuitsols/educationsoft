 
                <div class="col-md-6">
                    <p>
                        Writer Aaron Mahnke launched his podcast "Lore" in 2015 and it has gained critical acclaim in the time since, including earning Best of 2015 honors from iTunes. The audio program is now becoming a TV series as an anthology that, like the podcast, uncovers real-life events that spawned people's darke…
                    </p>
                </div>
                